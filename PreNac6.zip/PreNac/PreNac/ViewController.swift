//
//  ViewController.swift
//  PreNac
//
//  Created by Usuário Convidado on 22/08/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var lblBicho: UILabel!
    var nomeBicho:String=""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        lblBicho.text = nomeBicho
    }


}

